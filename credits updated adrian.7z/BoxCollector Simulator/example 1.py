import pygame
display_width = 600
display_height = 600
pygame.init()

GameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption('Test')

def Mainwindow():
    MenuStay = True

    while MenuStay:
        GameDisplay.fill((255,255,255))
        pygame.display.update()

        for event in pygame.event.get():
            print(event)

            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        

Mainwindow()
