import pickle
SettingsDict = {'BlueNumS':'7','RedNumS':'7','TimeNumS':'40','RedBoxS':'4','BlueBoxS':'4'}
SettingsFile = open('BCSettings.txt','wb')
pickle.dump(SettingsDict,SettingsFile)
SettingsFile.close()
